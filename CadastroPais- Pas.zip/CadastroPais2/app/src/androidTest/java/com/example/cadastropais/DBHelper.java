package com.example.cadastropais;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "cadastros.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_PAI = "pai";
    public static final String COL_ID = "id";
    public static final String COL_NOME = "nome";
    public static final String COL_SOBRENOME = "sobrenome";
    public static final String COL_EMAIL = "email";
    public static final String COL_IDADE = "idade";
    public static final String COL_ENDERECO = "endereco";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create = "CREATE TABLE " + TABLE_PAI + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NOME + " TEXT, " +
                COL_SOBRENOME + " TEXT, " +
                COL_EMAIL + " TEXT, " +
                COL_IDADE + " INTEGER, " +
                COL_ENDERECO + " TEXT)";
        db.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PAI);
        onCreate(db);
    }

    // Inserir
    public long inserirPai(Pai p) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_NOME, p.getNome());
        cv.put(COL_SOBRENOME, p.getSobrenome());
        cv.put(COL_EMAIL, p.getEmail());
        cv.put(COL_IDADE, p.getIdade());
        cv.put(COL_ENDERECO, p.getEndereco());
        long id = db.insert(TABLE_PAI, null, cv);
        db.close();
        return id;
    }

    // Buscar todos
    public ArrayList<Pai> buscarTodos() {
        ArrayList<Pai> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_PAI, null, null, null, null, null, COL_ID + " DESC");
        if (c != null) {
            while (c.moveToNext()) {
                Pai p = new Pai();
                p.setId(c.getLong(c.getColumnIndexOrThrow(COL_ID)));
                p.setNome(c.getString(c.getColumnIndexOrThrow(COL_NOME)));
                p.setSobrenome(c.getString(c.getColumnIndexOrThrow(COL_SOBRENOME)));
                p.setEmail(c.getString(c.getColumnIndexOrThrow(COL_EMAIL)));
                p.setIdade(c.getInt(c.getColumnIndexOrThrow(COL_IDADE)));
                p.setEndereco(c.getString(c.getColumnIndexOrThrow(COL_ENDERECO)));
                lista.add(p);
            }
            c.close();
        }
        db.close();
        return lista;
    }
}
