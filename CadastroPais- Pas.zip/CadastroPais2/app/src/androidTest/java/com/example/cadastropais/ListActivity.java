package com.example.cadastropais;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    ListView listView;
    DBHelper dbHelper;
    ArrayList<Pai> lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        listView = findViewById(R.id.listViewPais);
        dbHelper = new DBHelper(this);
        carregarLista();
    }

    private void carregarLista() {
        lista = dbHelper.buscarTodos();
        ArrayList<String> exibicao = new ArrayList<>();
        for (Pai p : lista) {
            String texto = p.getNomeCompleto() + " - " + p.getEmail() + "\nIdade: " + p.getIdade() + " - " + p.getEndereco();
            exibicao.add(texto);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, exibicao);
        listView.setAdapter(adapter);
    }
}

