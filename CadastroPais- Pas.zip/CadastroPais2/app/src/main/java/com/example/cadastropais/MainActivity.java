package com.example.cadastropais;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etNome, etSobrenome, etEmail, etIdade, etEndereco;
    Button btnSalvar, btnVer;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNome = findViewById(R.id.etNome);
        etSobrenome = findViewById(R.id.etSobrenome);
        etEmail = findViewById(R.id.etEmail);
        etIdade = findViewById(R.id.etIdade);
        etEndereco = findViewById(R.id.etEndereco);
        btnSalvar = findViewById(R.id.btnSalvar);
        btnVer = findViewById(R.id.btnVer);

        dbHelper = new DBHelper(this);

        btnSalvar.setOnClickListener(v -> {
            String nome = etNome.getText().toString().trim();
            String sobrenome = etSobrenome.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String idadeStr = etIdade.getText().toString().trim();
            String endereco = etEndereco.getText().toString().trim();

            if (TextUtils.isEmpty(nome) || TextUtils.isEmpty(sobrenome) ||
                    TextUtils.isEmpty(email) || TextUtils.isEmpty(idadeStr)) {
                Toast.makeText(this, "Preencha todos os campos obrigatórios.", Toast.LENGTH_SHORT).show();
                return;
            }

            int idade;
            try {
                idade = Integer.parseInt(idadeStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Idade inválida.", Toast.LENGTH_SHORT).show();
                return;
            }

            Pai p = new Pai(nome, sobrenome, email, idade, endereco);
            long id = dbHelper.inserirPai(p);
            if (id != -1) {
                Toast.makeText(this, "Salvo com sucesso!", Toast.LENGTH_SHORT).show();
                limparCampos();
            } else {
                Toast.makeText(this, "Erro ao salvar.", Toast.LENGTH_SHORT).show();
            }
        });

        btnVer.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, ListActivity.class);
            startActivity(i);
        });
    }

    private void limparCampos() {
        etNome.setText("");
        etSobrenome.setText("");
        etEmail.setText("");
        etIdade.setText("");
        etEndereco.setText("");
    }
}

